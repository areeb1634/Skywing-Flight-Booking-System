import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Home } from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import AdminDashboard from "./pages/AdminPages/AdminDashboard";
import ProtectedRoute from "./Routers/ProtectedRoute";
import BookingForm from "./pages/UserPages/BookingForm";
import Confirmation from "./pages/UserPages/Confirmation";
import MyBookings from "./pages/UserPages/MyBookings";
import BlogPage from "./pages/UserPages/BlogPage";
import ContactPage from "./pages/UserPages/Contact";

export default function FlightBookingApp() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* User Protected Routes */}
        <Route
          path="/book/:flightId"
          element={
            <ProtectedRoute allowed="user">
              <BookingForm />
            </ProtectedRoute>
          }
        />
        <Route
          path="/my-bookings"
          element={
            <ProtectedRoute allowed="user">
              <MyBookings />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blog"
          element={
            <ProtectedRoute allowed="user">
              <BlogPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/contact"
          element={
            <ProtectedRoute allowed="user">
              <ContactPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/confirmation"
          element={
            <ProtectedRoute allowed="user">
              <Confirmation />
            </ProtectedRoute>
          }
        />

        {/* Admin Protected Route */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute allowed="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}
