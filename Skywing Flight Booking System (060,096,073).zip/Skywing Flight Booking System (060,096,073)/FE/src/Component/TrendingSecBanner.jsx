import { Box, Typography, Card, CardContent, CardMedia } from "@mui/material";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

const destinations = [
  {
    city: "Cairo",
    country: "Egypt",
    img: "https://www.magnificenttravel.com/public/uploads/2025/01/26/67965360b48af/Cairo-Sultan-Hassan-Mosque--.jpg",
  },
  {
    city: "Amman",
    country: "Jordan",
    img: "https://static.independent.co.uk/2023/11/02/16/newFile.jpg",
  },
  {
    city: "Bangkok",
    country: "Thailand",
    img: "https://static.independent.co.uk/2025/01/03/14/newFile-12.jpg",
  },
  {
    city: "London",
    country: "United Kingdom",
    img: "https://i.natgeofe.com/n/4def1048-f5e5-4973-ad3a-e188a97d363f/regents-street-london-england.jpg",
  },
  {
    city: "Paris",
    country: "France",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuIhmhSMBC44mycWicjO6jHLghQWEmzksW4Q&s",
  },
  {
    city: "Melbourne",
    country: "Australia",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOSz11AS4ZSlw24vcmZ5-P8Ls_VvrkOkV5IA&s",
  },
];

export default function TrendingDestinations() {
  return (
    <Box sx={{ width: "100%", maxWidth: 1400, mx: "auto", px: 0, mt: 6 }}>
      <Typography variant="h5" fontWeight="bold" mb={3} align="center">
        Trending summer destinations from Karachi
      </Typography>

      <Swiper
        modules={[Navigation]}
        navigation
        spaceBetween={16}
        slidesPerView={1.2}
        style={{ paddingBottom: "20px" }}
        breakpoints={{
          600: { slidesPerView: 2 },
          900: { slidesPerView: 3 },
          1200: { slidesPerView: 4 },
        }}
      >
        {destinations.map((d, i) => (
          <SwiperSlide key={i}>
            <Card
              sx={{
                borderRadius: 2,
                overflow: "hidden",
                height: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <CardMedia
                component="img"
                height="160"
                image={d.img}
                alt={d.city}
                sx={{ objectFit: "cover" }}
              />
              <CardContent>
                <Typography variant="subtitle1" fontWeight="bold">
                  {d.city}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {d.country}
                </Typography>
              </CardContent>
            </Card>
          </SwiperSlide>
        ))}
      </Swiper>
    </Box>
  );
}
