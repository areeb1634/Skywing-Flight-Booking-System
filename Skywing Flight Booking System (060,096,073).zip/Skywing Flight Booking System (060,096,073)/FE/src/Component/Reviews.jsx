import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Divider,
} from "@mui/material";
import StarIcon from "@mui/icons-material/Star";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";

const reviews = [
  {
    name: "Mele Puamau",
    date: "May 29, 2025",
    title: "Family vacation",
    content:
      "I highly recommend others to utilize Cheapoair.com! It was an amazing trip especially last min booking. Thank you so much for allowing me to experience great unforgettable trip",
  },
  {
    name: "Alexia Taylor",
    date: "May 17, 2025",
    title: "Loved It",
    content:
      "The overall trip was fantastic and I would recommend any of my friends that love to travel. I would definitely travel again with you guys.",
  },
  {
    name: "Daren Bolton",
    date: "May 15, 2025",
    title: "GREAT SERVICE",
    content:
      "HAVE BEEN BOOKING MY FLIGHTS WITH CHEAPOAIR FOR OVER FIVE YEARS AND THEIR SERVICES ARE ALWAYS DEPENDABLE WITH GOOD PRICES COMPAR...",
  },
];

export default function CustomerReviews() {
  return (
    <Box sx={{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center"}}>
      <Typography variant="h5" fontWeight="bold" textAlign="center" mb={3}>
        What Our Customers Say About Our Service?
      </Typography>

      {/* Review Cards */}
      <Box sx={{ maxWidth: 1200, mx: "auto" }}>
        <Box
          sx={{
            display: "flex",
            flexWrap: "wrap",
            gap: 4,
            justifyContent: { xs: "center", md: "center" }, // Center on small screens
          }}
        >
          {reviews.map((review, idx) => (
            <Card
              key={idx}
              sx={{
                flex: "1 1 300px", // Responsive column width
                maxWidth: 340, // Prevent card from growing too wide
                p: 2,
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
                {[...Array(5)].map((_, i) => (
                  <StarIcon key={i} sx={{ fontSize: 18, color: "#ffc107" }} />
                ))}
              </Box>
              <Typography fontWeight="bold">{review.name}</Typography>
              <Box
                sx={{ display: "flex", alignItems: "center", gap: 1, my: 1 }}
              >
                <CalendarTodayIcon sx={{ fontSize: 16, color: "gray" }} />
                <Typography variant="body2" color="text.secondary">
                  {review.date}
                </Typography>
              </Box>
              <Typography fontWeight="bold" sx={{ mb: 1 }}>
                {review.title}
              </Typography>
              <Typography variant="body2" sx={{ mb: 1 }}>
                {review.content}
              </Typography>
              <Typography
                variant="body2"
                color="primary"
                sx={{ cursor: "pointer" }}
              >
                Read More
              </Typography>
            </Card>
          ))}
        </Box>
      </Box>

      <Typography
        align="center"
        mt={4}
        color="primary"
        sx={{ cursor: "pointer" }}
      >
        See All Reviews
      </Typography>
    </Box>
  );
}
