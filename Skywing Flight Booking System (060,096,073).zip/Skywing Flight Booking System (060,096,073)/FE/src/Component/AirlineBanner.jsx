import { Box, Typography } from "@mui/material";
import { motion } from "framer-motion";

const airlineLogos = [
  "https://images.seeklogo.com/logo-png/19/2/turkish-airlines-logo-png_seeklogo-194656.png",
  "https://png.pngtree.com/png-clipart/20190603/original/pngtree-vector-airlines-personality-logo-png-image_618635.jpg",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSM576u1Lu78_0h3Bw_lYcj7R6um7t77BGQTQ&s",
  "https://1000logos.net/wp-content/uploads/2020/04/Singapore-Airlines-Logo.png",
  "https://download.logo.wine/logo/Canadian_Airlines/Canadian_Airlines-Logo.wine.png",
];

function AirlineBanner() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Box
        sx={{
          border: "1px solid #ccc",
          borderRadius: 2,
          mt: 6,
          p: { xs: 2, sm: 2 },
          textAlign: "center",
          backgroundColor: "#fafafa",
          mx: "auto",
          width: {
            xs: "90%",   // Mobile
            sm: "85%",   // Small tablets
            md: "90%",   // Landscape tablets and up
            lg: "100%"    // Desktops
          }
        }}
      >
        <Typography
          variant="subtitle1"
          fontWeight="bold"
          mb={2}
          sx={{ fontSize: { xs: 16, sm: 18, md: 20 } }}
        >
          Search hundreds of airlines at once
        </Typography>

        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: { xs: 2, sm: 3 },
            flexWrap: "wrap"
          }}
        >
          {airlineLogos.map((url, i) => (
            <Box
              key={i}
              component="img"
              src={url}
              alt="airline logo"
              sx={{
                height: { xs: 40, sm: 60, md: 80 },
                objectFit: "contain"
              }}
            />
          ))}
        </Box>
      </Box>
    </motion.div>
  );
}

export default AirlineBanner;
