import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Avatar,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function Navbar() {
  const navigate = useNavigate();
  const userEmail = localStorage.getItem("userEmail");
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleMenu = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleLogout = () => {
    localStorage.removeItem("userEmail");
    navigate("/login");
    handleClose();
  };

  return (
    <AppBar
      position="static"
      sx={{
        background: "linear-gradient(135deg, #1976d2 0%, #2196f3 100%)",
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
        py: 1,
      }}
    >
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        {/* Left: Brand + Nav Links */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 4 }}>
          <Box
            onClick={() => navigate("/")}
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1.5,
              cursor: "pointer",
            }}
          >
            <img
              src="https://i.pinimg.com/736x/62/99/2a/62992ac42457cc18e8254ae399242e50.jpg"
              alt="SkyWing Logo"
              style={{ width: 65, height: 50, borderRadius: 4 }}
            />
            <Typography
              variant="h6"
              sx={{ fontWeight: "bold", color: "white" }}
            >
              SkyWing Booking
            </Typography>
          </Box>

          <Box sx={{ display: { xs: "none", md: "flex" }, gap: 2 }}>
            <Button
              color="inherit"
              sx={{
                textTransform: "none",
                fontSize: "1rem",
                "&:hover": { backgroundColor: "rgba(255,255,255,0.1)" },
              }}
              onClick={() => navigate("/")}
            >
              Home
            </Button>
            <Button
              color="inherit"
              sx={{
                textTransform: "none",
                fontSize: "1rem",
                "&:hover": { backgroundColor: "rgba(255,255,255,0.1)" },
              }}
              onClick={() => navigate("/blog")}
            >
              Blog
            </Button>
            <Button
              color="inherit"
              sx={{
                textTransform: "none",
                fontSize: "1rem",
                "&:hover": { backgroundColor: "rgba(255,255,255,0.1)" },
              }}
              onClick={() => navigate("/contact")}
            >
              Contact
            </Button>
          </Box>
        </Box>

        {/* Right: Auth/Profile Section */}
        {userEmail ? (
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <IconButton onClick={handleMenu} color="inherit" sx={{ p: 0 }}>
              <Avatar
                sx={{
                  bgcolor: "white",
                  color: "#1976d2",
                  fontWeight: "bold",
                  width: 36,
                  height: 36,
                }}
              >
                {userEmail.charAt(0).toUpperCase()}
              </Avatar>
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              anchorOrigin={{ vertical: "top", horizontal: "right" }}
              transformOrigin={{ vertical: "top", horizontal: "right" }}
            >
              <MenuItem disabled>{userEmail}</MenuItem>
              <MenuItem onClick={() => navigate("/my-bookings")}>
                My Bookings
              </MenuItem>
              <MenuItem onClick={handleLogout}>Logout</MenuItem>
            </Menu>
          </Box>
        ) : (
          <Box sx={{ display: "flex", gap: 1 }}>
            <Button
              variant="outlined"
              color="inherit"
              sx={{
                textTransform: "none",
                borderRadius: 20,
                px: 3,
                "&:hover": { backgroundColor: "rgba(255,255,255,0.1)" },
              }}
              onClick={() => navigate("/login")}
            >
              Login
            </Button>
            <Button
              variant="contained"
              color="secondary"
              sx={{
                textTransform: "none",
                borderRadius: 20,
                px: 3,
                boxShadow: "none",
                "&:hover": {
                  backgroundColor: "#f50057",
                  boxShadow: "none",
                },
              }}
              onClick={() => navigate("/signup")}
            >
              Sign Up
            </Button>
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
}
