import React from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Link,
  Divider,
  List,
  ListItem,
  ListItemText,
  useTheme,
  useMediaQuery
} from '@mui/material';

const Footer = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const sections = [
    {
      title: 'Book',
      links: [
        'Cheap Topics',
        'Cheap Hosts',
        'Car Rentals',
        'Vacation Packages',
        'Going Travel',
        'Save & Earn $',
        'Local Guides'
      ]
    },
    {
      title: 'Traveler Tours',
      links: [
        'Off Cards',
        'Check My Booking',
        'Customer Support',
        'Online Check in',
        'Attire Biggage Fees',
        'Check Flight Status',
        'Travel Blog'
      ]
    },
    {
      title: 'About Cheapout',
      links: [
        'About Us',
        'Press Room',
        'Careers',
        'Affiliate Program',
        'Client Testimonials',
        'Advertise with Us',
        'Newsletter'
      ]
    },
    {
      title: 'Legal',
      links: [
        'Privacy Policy',
        'Cookie Policy',
        'Price Match Promise',
        'Terms & Conditions',
        'Taxes & Fees',
        'Off Service Fees',
        'Post-Trading Fees',
        'Compassion Exception Policy',
        'Connection Protection',
        'Consumer Health Data Notice'
      ]
    }
  ];

  const quickLinks = [
    'Popular Airlines',
    'Popular Flight Routes',
    'Top U.S. Destinations',
    'Top International Destinations',
    'Site Directorate',
    'Stay Connected',
    'International Sites'
  ];

  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: theme.palette.grey[100],
        color: theme.palette.text.secondary,
        py: 6,
        mt: 'auto'
      }}
    >
      <Container maxWidth="xl">
        {/* Easy Access Section */}
        <Box sx={{ mb: 6 }}>
          <Typography
            variant="h5"
            fontWeight="bold"
            textAlign={isMobile ? 'start' : 'left'}
            mb={2}
          >
            Easy Access
          </Typography>
          <Typography
            variant="h6"
            sx={{ mb: 3 }}
            textAlign={isMobile ? 'center' : 'left'}
          >
            Guide Links
          </Typography>
          <Grid container spacing={2} justifyContent={isMobile ? 'center' : 'flex-start'}>
            {quickLinks.map((link) => (
              <Grid item xs={6} sm={4} md={2} key={link}>
                <Link
                  href="#"
                  color="inherit"
                  underline="hover"
                  sx={{ display: 'inline-block' }}
                  aria-label={link}
                >
                  {link}
                </Link>
              </Grid>
            ))}
          </Grid>
        </Box>

        <Divider sx={{ my: 4 }} />

        {/* Main Footer Sections */}
        <Grid
          container
          spacing={isMobile ? 2 : 4}
          justifyContent={isMobile ? 'start' : 'flex-start'}
        >
          {sections.map((section) => (
            <Grid
              item
              xs={6}
              sm={6}
              md={3}
              key={section.title}
              textAlign={isMobile ? 'start' : 'left'}
            >
              <Typography
                variant="h6"
                fontWeight="bold"
                mb={2}
              >
                {section.title}
              </Typography>
              <List dense disablePadding>
                {section.links.map((link) => (
                  <ListItem
                    key={link}
                    disableGutters
                    disablePadding
                    sx={{ justifyContent: isMobile ? 'center' : 'flex-start' }}
                  >
                    <ListItemText
                      primary={
                        <Link
                          href="#"
                          color="inherit"
                          underline="hover"
                          sx={{ display: 'inline-block', py: 0.5 }}
                          aria-label={link}
                        >
                          {link}
                        </Link>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </Grid>
          ))}
        </Grid>

        <Divider sx={{ my: 4 }} />

        {/* Copyright */}
        <Box sx={{ textAlign: 'center', mt: 3, px: 2 }}>
          <Typography variant="body2">
            © 2006 - 2025 Fangdell, Inc. All rights reserved.
          </Typography>
          <Typography
            variant="caption"
            sx={{ display: 'block', mt: 1, wordBreak: 'break-word' }}
          >
            (https://fabry.net/open-to-air limits and Controllers, Certificate:
            CST 2027/3454, Fonds: ST21404, Israel: 50217545-7500-0, Washington:
            WHOOT 1990752828)
          </Typography>
          <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
            (affiliate of Frontiers, Inc.)
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};

export default Footer;
