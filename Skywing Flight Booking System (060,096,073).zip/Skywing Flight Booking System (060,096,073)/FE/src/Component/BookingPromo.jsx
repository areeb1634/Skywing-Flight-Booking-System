import React from 'react';
import { 
  Box,
  Typography,
  Container,
  List,
  ListItem,
  ListItemIcon,
  Button,
  Divider,
  Paper,
  Grid,
  useTheme
} from '@mui/material';
import QrCode2Icon from '@mui/icons-material/QrCode2';
import CheckCircleIcon from '@mui/icons-material/CheckCircle'; // Filled check circle
// Alternatively, for outlined version:
// import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';

const FlightBookingPromo = () => {
  const theme = useTheme();

  return (
    <Container sx={{ py: 2,}}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        {/* Header Section */}
        <Box sx={{ mb: 4 }}>
          <Typography 
            variant="h4" 
            component="h1" 
            sx={{ 
              fontWeight: 'bold',
              mb: 2,
              color: theme.palette.primary.main
            }}
          >
            Book Cheap Flights on CheapOair
          </Typography>
          
          <Typography variant="body1" paragraph>
            Why pay full price for your next flight when you can take advantage of cheap flights on CheapOair? 
            We offer unbelievable savings on flights worldwide, so whether you're looking for a weekend getaway 
            or a once-in-a-lifetime trip around the globe, we can get you there for less.
          </Typography>
          
          <Typography variant="body1">
            Even better: we update our discount airfares constantly, so you can find new deals on CheapOair 
            every few seconds! On your next trip, don't take your chances anywhere else.
          </Typography>
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* Points Promotion Section */}
        <Box sx={{ mb: 4 }}>
          <Typography 
            variant="h5" 
            component="h2" 
            sx={{ 
              fontWeight: 'bold',
              mb: 2,
              color: theme.palette.secondary.main
            }}
          >
            Earn 2X points on CheapOair app
          </Typography>
          
          <Typography variant="body1" paragraph>
            Book on our apps (iOS & Android) to double your points.
          </Typography>

          <List dense>
            <ListItem>
              <ListItemIcon sx={{ minWidth: 32 }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <Typography variant="body1">
                Get notified when prices drop for trips you are planning
              </Typography>
            </ListItem>
            <ListItem>
              <ListItemIcon sx={{ minWidth: 32 }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <Typography variant="body1">
                Change or cancel your flights on the go!
              </Typography>
            </ListItem>
            <ListItem>
              <ListItemIcon sx={{ minWidth: 32 }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <Typography variant="body1">
                Get flight alerts and updates for your trips
              </Typography>
            </ListItem>
          </List>
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* QR Code Section */}
        <Grid container alignItems="center" spacing={3}>
          <Grid item xs={12} sm={6}>
            <Typography variant="h6" sx={{ mb: 1 }}>
              Scan QR and install
            </Typography>
            <Button 
              variant="contained" 
              color="primary" 
              startIcon={<QrCode2Icon />}
              sx={{ textTransform: 'none' }}
            >
              Show QR Code
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} sx={{ display: 'flex', justifyContent: 'center' }}>
            {/* Placeholder for QR code - in a real app you would use a QR code component */}
            <Box 
              sx={{ 
                width: 150, 
                height: 150, 
                bgcolor: '#f5f5f5', 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center',
                border: '1px dashed #ccc'
              }}
            >
              <Typography variant="caption" color="textSecondary">
                <img style={{width:"100%",objectFit:"cover"}} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwt7ZEmrByG2bCVGw8QlVDNbujqGHfTDRinN1jmzb201ERuAjZwhsbgEMJL_UFKWPSiVc&usqp=CAU" alt="" />
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
};

export default FlightBookingPromo;