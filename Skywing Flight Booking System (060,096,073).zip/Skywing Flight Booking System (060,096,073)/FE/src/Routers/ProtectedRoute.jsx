// components/ProtectedRoute.jsx
import React from "react";
import { Navigate } from "react-router-dom";

export default function ProtectedRoute({ children, allowed }) {
  const userEmail = localStorage.getItem("userEmail");

  if (!userEmail) {
    return <Navigate to="/login" />;
  }

  if (allowed === "admin" && userEmail !== "admin@gmail.com") {
    return <Navigate to="/" />;
  }

  if (allowed === "user" && userEmail === "admin@gmail.com") {
    return <Navigate to="/admin" />;
  }

  return children;
}
