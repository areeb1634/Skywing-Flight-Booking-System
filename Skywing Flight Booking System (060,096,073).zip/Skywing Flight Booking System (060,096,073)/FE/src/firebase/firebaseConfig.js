// firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore"; // If using roles

const firebaseConfig = {
  apiKey: "AIzaSyDFd--ak67TW6cEC-WOH2uSfEL67YneBs4",
  authDomain: "dbms-project-81437.firebaseapp.com",
  projectId: "dbms-project-81437",
  storageBucket: "dbms-project-81437.firebasestorage.app",
  messagingSenderId: "263718397899",
  appId: "1:263718397899:web:c0e8d6f6b0f87e7f84b84e"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app); // Optional: Firestore
