import React, { useState } from "react";
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  Link,
  useTheme,
  useMediaQuery
} from "@mui/material";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/firebaseConfig";
import { useNavigate, Link as RouterLink } from "react-router-dom";
import { motion } from "framer-motion";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, email, password);
      localStorage.setItem("userEmail", email);
      navigate("/");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Box
      sx={{
        width: "100%",
        minHeight: "98vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "linear-gradient(to right, #00c6ff, #0072ff)",
        px: 2,
        boxSizing: "border-box"
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{
          width: "100%",
          maxWidth: 450,
          margin: "0 auto"
        }}
      >
        <Paper
          elevation={6}
          sx={{
            p: { xs: 3, sm: 4 },
            borderRadius: { xs: 2, sm: 4 },
            width: "100%",
            boxSizing: "border-box"
          }}
        >
          <Typography
            variant="h4"
            textAlign="center"
            gutterBottom
            sx={{
              fontWeight: 600,
              fontSize: { xs: "1.5rem", sm: "2rem" }
            }}
          >
            Login
          </Typography>
          
          <Box component="form" onSubmit={handleLogin}>
            <TextField
              label="Email"
              type="email"
              fullWidth
              required
              margin="normal"
              size="medium"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              sx={{ mb: 2 }}
            />
            
            <TextField
              label="Password"
              type="password"
              fullWidth
              required
              margin="normal"
              size="medium"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              sx={{ mb: 2 }}
            />
            
            {error && (
              <Typography
                color="error"
                sx={{
                  mt: 1,
                  fontSize: "0.875rem"
                }}
              >
                {error}
              </Typography>
            )}
            
            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              sx={{
                mt: 3,
                py: 1.5,
                fontWeight: "bold"
              }}
            >
              Login
            </Button>
            
            <Typography
              sx={{
                mt: 2,
                textAlign: "center",
                fontSize: "1rem"
              }}
            >
              Don't have an account?{" "}
              <Link
                component={RouterLink}
                to="/signup"
                sx={{
                  fontSize: "inherit"
                }}
              >
                Sign up here
              </Link>
            </Typography>
            
            <Typography
              sx={{
                mt: 1,
                textAlign: "center",
                fontSize: "1rem"
              }}
            >
              <Link
                component={RouterLink}
                to="/"
                sx={{
                  fontSize: "inherit"
                }}
              >
                ← Back to Home
              </Link>
            </Typography>
          </Box>
        </Paper>
      </motion.div>
    </Box>
  );
}