import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
// import { Box, Typography } from "@mui/material";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Container,
  Grid,
  Paper,
  useTheme,
  useMediaQuery,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody
} from "@mui/material";
import { motion } from "framer-motion";
import axios from "axios";
import AirlineBanner from "../Component/AirlineBanner";
import TrendingDestinations from "../Component/TrendingSecBanner";
import CustomerReviews from "../Component/Reviews";
import FlightBookingPromo from "../Component/BookingPromo";
import Footer from "../Component/Footer";
// import { motion } from "framer-motion";
import FlightTakeoffIcon from "@mui/icons-material/FlightTakeoff";
import FlightLandIcon from "@mui/icons-material/FlightLand";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import Navbar from "../Component/Navbar";

export function Home() {
  const navigate = useNavigate();
  const [flights, setFlights] = useState([]);
  const theme = useTheme();
  const userEmail = localStorage.getItem('userEmail');
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  useEffect(() => {
    const userEmail = localStorage.getItem("userEmail");

    if (userEmail === "admin@gmail.com") {
      navigate("/admin");
      return; // stop further execution
    }

    axios
      .get("http://localhost:5000/flights")
      .then((res) => setFlights(res.data))
      .catch((err) => console.error("Error fetching flights", err));
  }, [navigate]);
  return (
    <Box>
      {/* Navbar */}
     <Navbar />

      {/* Hero */}
      <Box
        sx={{
          backgroundImage: `url("https://www.shutterstock.com/image-photo/white-passenger-airplane-flying-sky-600nw-2471932239.jpg")`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          color: "#000000",
          minHeight: "60vh",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Container>
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Typography variant="h3" fontWeight="bold" gutterBottom>
              Book Flights with Ease
            </Typography>
            <Typography variant="h6" gutterBottom>
              Explore the world with comfort. Find your flight now!
            </Typography>
          </motion.div>
        </Container>
      </Box>

      {/* Flight List */}
      <Box sx={{ maxHeight: '100vh', overflowY: 'auto', px: 2,mt:3 }}>
        <Typography variant="h5" fontWeight="bold" mb={3}>
          Available Flights
        </Typography>

        {/* Mobile version as Cards */}
        {isMobile ? (
          <Grid container spacing={3} sx={{ flexDirection: "column", flexWrap: "nowrap" }}>
            {flights.map((flight) => (
              <Grid item xs={12} key={flight.id}>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <Paper elevation={3} sx={{ p: 3, borderRadius: 2 }}>
                    <Typography
                      fontWeight="bold"
                      sx={{ display: "flex", alignItems: "center", mb: 1 }}
                    >
                      <FlightTakeoffIcon fontSize="small" sx={{ mr: 1 }} />
                      {flight.fromCity}
                      <FlightLandIcon fontSize="small" sx={{ mx: 1 }} />
                      {flight.toCity}
                    </Typography>
                    <Typography
                      sx={{ display: "flex", alignItems: "center", mb: 1 }}
                    >
                      <CalendarTodayIcon fontSize="small" sx={{ mr: 1 }} />
                      {new Date(flight.departureTime).toLocaleDateString()}
                    </Typography>
                    <Typography>
                      Price: <strong>Rs. {flight.price}</strong>
                    </Typography>

                    {userEmail ? (
                      <Button
                        variant="contained"
                        sx={{ mt: 2 }}
                        onClick={() => navigate(`/book/${flight.id}`)}
                      >
                        Book Now
                      </Button>
                    ) : (
                      <Button
                        variant="outlined"
                        color="warning"
                        sx={{ mt: 2 }}
                        onClick={() => navigate("/login")}
                      >
                        Login to Book
                      </Button>
                    )}
                  </Paper>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        ) : (
          // Desktop version as Table
          <TableContainer component={Paper} elevation={4}>
            <Table>
              <TableHead sx={{ backgroundColor: theme.palette.grey[200] }}>
                <TableRow>
                  <TableCell>
                    <strong>From → To</strong>
                  </TableCell>
                  <TableCell>
                    <strong>Date</strong>
                  </TableCell>
                  <TableCell>
                    <strong>Price</strong>
                  </TableCell>
                  <TableCell>
                    <strong>Action</strong>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {flights.map((flight, idx) => (
                  <TableRow
                    key={flight.id}
                    sx={{
                      backgroundColor:
                        idx % 2 === 0 ? "white" : theme.palette.grey[50],
                      "&:hover": {
                        backgroundColor: theme.palette.action.hover,
                      },
                    }}
                  >
                    <TableCell>
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <FlightTakeoffIcon fontSize="small" sx={{ mr: 1 }} />
                        {flight.fromCity}
                        <FlightLandIcon fontSize="small" sx={{ mx: 1 }} />
                        {flight.toCity}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <CalendarTodayIcon fontSize="small" sx={{ mr: 1 }} />
                        {new Date(flight.departureTime).toLocaleDateString()}
                      </Box>
                    </TableCell>
                    <TableCell>Rs. {flight.price}</TableCell>
                    <TableCell>
                      {userEmail ? (
                        <Button
                          variant="contained"
                          size="small"
                          onClick={() => navigate(`/book/${flight.id}`)}
                        >
                          Book Now
                        </Button>
                      ) : (
                        <Button
                          variant="outlined"
                          size="small"
                          color="warning"
                          onClick={() => navigate("/login")}
                        >
                          Login to Book
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>

      {/* Airlines Banner */}
      <Box sx={{ maxWidth: 1200, mx: "auto" }}>
        <AirlineBanner />
      </Box>

      {/* Trending Locations Banner */}
      <Box sx={{ maxWidth: 1200, mx: "auto", mt: 6 }}>
        <TrendingDestinations />
      </Box>

      {/* Reviews */}
      <Box sx={{ maxWidth: 1200, mx: "auto", mt: 6, mb: 8 }}>
        <CustomerReviews />
      </Box>

      {/* Promo */}
      <Box sx={{ maxWidth: 1200, mx: "auto", mt: 6, mb: 8 }}>
        <FlightBookingPromo />
      </Box>

      {/* Footer */}

      <Footer />
    </Box>
  );
}
