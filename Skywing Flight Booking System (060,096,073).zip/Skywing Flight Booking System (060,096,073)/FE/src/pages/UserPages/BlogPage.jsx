import React from "react";
import { Container, Typography, Box, Grid, Paper } from "@mui/material";
import Navbar from "../../Component/Navbar";
import Footer from "../../Component/Footer";
import './blog.css';

const BlogPage = () => {
  return (
    <Box sx={{ backgroundColor: "#f9f9f9" }}>
      <Navbar />
      <Container maxWidth="lg" sx={{ py: 6 }}>
        <Paper elevation={3} sx={{ p: 4, mb: 4 }}>
          <Typography
            variant="h3"
            gutterBottom
            sx={{ fontWeight: "bold", color: "primary.main" }}
          >
            Welcome to SkyWing Booking
          </Typography>
          <Typography variant="body1" paragraph>
            At <strong>SkyWing</strong>, we are revolutionizing the way Pakistan
            flies. Established in 2024 by a team of passionate aviation and tech
            enthusiasts, SkyWing is a modern, user-friendly flight booking
            system designed to make air travel more accessible and efficient
            across the country. Whether you're flying from Karachi to Skardu or
            planning a business trip from Lahore to Islamabad, SkyWing has got
            you covered.
          </Typography>

          <Box sx={{ display: "flex", justifyContent: "center" }}>
            <img
            className="fillspace"
              src="https://www.shutterstock.com/image-vector/3d-white-abstract-airliner-take-600nw-1894504804.jpg"
              alt="SkyWing Aircraft"
              style={{ borderRadius: "12px", margin: "20px 0" }}
            />
          </Box>

          <Typography
            variant="h5"
            gutterBottom
            sx={{ fontWeight: "bold", mt: 4 }}
          >
            Our Mission
          </Typography>
          <Typography variant="body1" paragraph>
            Our mission is to build Pakistan’s most reliable and user-centric
            flight booking experience. We aim to make air travel more convenient
            and accessible, especially for remote and underserved regions. We
            work in collaboration with major airlines and local air charters to
            offer real-time seat availability, secure online payments, and
            instant confirmations.
          </Typography>

          <Typography
            variant="h5"
            gutterBottom
            sx={{ fontWeight: "bold", mt: 4 }}
          >
            Why Choose SkyWing?
          </Typography>
          <ul>
            <li>
              <Typography variant="body1">
                Fast and secure booking with real-time updates
              </Typography>
            </li>
            <li>
              <Typography variant="body1">
                Wide range of destinations within Pakistan
              </Typography>
            </li>
            <li>
              <Typography variant="body1">
                24/7 customer support and assistance
              </Typography>
            </li>
            <li>
              <Typography variant="body1">
                User-friendly dashboard for both admins and passengers
              </Typography>
            </li>
            <li>
              <Typography variant="body1">
                Innovative technology backed by modern web frameworks
              </Typography>
            </li>
          </ul>

          <Box sx={{display:"flex",justifyContent:"center"}}>
            <img
            className="fillspace"
              src="https://media.istockphoto.com/id/1316660437/vector/employee-experience-vector-icon-5-star-satisfaction-rating-vector-icon-rating-icon-5-star.jpg?s=170667a&w=0&k=20&c=PT2xnZYqyi5hjkk0B9dq_GQJzdDaNKNkO5iqKuXu4Ro="
              alt="Booking Experience"
              style={{
                height: "auto",
                borderRadius: "12px",
              }}
            />
          </Box>

          <Typography
  variant="h5"
  gutterBottom
  sx={{ fontWeight: "bold", mt: 4 }}
>
  Meet Our Team
</Typography>
<Typography variant="body1" paragraph>
  SkyWing is driven by a passionate team of developers, designers,
  customer experience managers, and aviation consultants. Our goal is
  to deliver a product that simplifies the complexities of flight
  booking while enhancing the user experience.
</Typography>

<Grid sx={{display:"flex",justifyContent:"center"}} container spacing={4} mt={2}>
  {/* CEO - Full width */}
  <Grid item xs={12} sm={12} md={12}>
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
      }}
    >
      <img
        src="https://icons.veryicon.com/png/o/internet--web/web-interface-flat/6606-male-user.png"
        alt="CEO"
        style={{ width: "140px", borderRadius: "50%" }}
      />
      <Typography variant="h6" mt={1}>
        Founder & CEO
      </Typography>
    </Box>
  </Grid>
  <Grid item xs={12} sm={12} md={12}>
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
      }}
    >
      <img
        src="https://icons.veryicon.com/png/o/internet--web/web-interface-flat/6606-male-user.png"
        alt="CEO"
        style={{ width: "140px", borderRadius: "50%" }}
      />
      <Typography variant="h6" mt={1}>
        CTO
      </Typography>
    </Box>
  </Grid>
  <Grid item xs={12} sm={12} md={12}>
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
      }}
    >
      <img
        src="https://icons.veryicon.com/png/o/internet--web/web-interface-flat/6606-male-user.png"
        alt="CEO"
        style={{ width: "140px", borderRadius: "50%" }}
      />
      <Typography variant="h6" mt={1}>
        Manager
      </Typography>
    </Box>
  </Grid>

  
</Grid>

          <Typography
            variant="h5"
            gutterBottom
            sx={{ fontWeight: "bold", mt: 6 }}
          >
            Future Goals
          </Typography>
          <Typography variant="body1" paragraph>
            We are currently expanding our services to international
            destinations and working to integrate advanced AI-driven features
            like smart fare prediction and voice-assisted bookings. Our vision
            is to become the #1 flight booking platform in South Asia.
          </Typography>

          <Typography
            variant="h5"
            gutterBottom
            sx={{ fontWeight: "bold", mt: 6 }}
          >
            Thank You for Choosing SkyWing ✈️
          </Typography>
          <Typography variant="body1" paragraph>
            Your journey means everything to us. Whether you're booking your
            first flight or your fiftieth, we’re here to make it smooth, simple,
            and affordable.
          </Typography>
        </Paper>
      </Container>

      <Footer />
    </Box>
  );
};

export default BlogPage;
