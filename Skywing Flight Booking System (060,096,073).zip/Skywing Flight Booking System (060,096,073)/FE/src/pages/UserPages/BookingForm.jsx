// pages/BookingForm.jsx
import React, { useEffect, useState } from "react";
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Alert,
  CircularProgress,
} from "@mui/material";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

export default function BookingForm() {
  const { flightId } = useParams();
  const navigate = useNavigate();
  const [flight, setFlight] = useState(null);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState("");

  const userEmail = localStorage.getItem("userEmail");

  useEffect(() => {
    const fetchFlight = async () => {
      try {
        const res = await axios.get("http://localhost:5000/flights");
        const found = res.data.find((f) => f.id.toString() === flightId);
        if (found) setFlight(found);
        else setError("Flight not found");
      } catch (err) {
        setError("Failed to load flight details");
      } finally {
        setLoading(false);
      }
    };
    fetchFlight();
  }, [flightId]);

  const handleBooking = async () => {
    if (!userEmail) {
      navigate("/login");
      return;
    }

    setBooking(true);
    try {
      await axios.post("http://localhost:5000/book", {
        userEmail,
        flightId,
      });
      setSuccessMsg("Flight booked successfully!");
      setTimeout(() => navigate("/my-bookings"), 1500); // Optional: redirect after 1.5s
    } catch (err) {
      setError("Booking failed. Try again.");
    } finally {
      setBooking(false);
    }
  };

  if (loading) {
    return (
      <Box textAlign="center" mt={10}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container>
        <Alert severity="error" sx={{ mt: 4 }}>
          {error}
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="sm" sx={{ mt: 6 }}>
      <Paper elevation={4} sx={{ p: 4, borderRadius: 3 }}>
        <Typography variant="h5" mb={2} fontWeight="bold">
          Booking Summary
        </Typography>

        <Typography>
          <strong>Flight:</strong> {flight.flightNumber}
        </Typography>
        <Typography>
          <strong>From:</strong> {flight.fromCity}
        </Typography>
        <Typography>
          <strong>To:</strong> {flight.toCity}
        </Typography>
        <Typography>
          <strong>Departure:</strong>{" "}
          {new Date(flight.departureTime).toLocaleString()}
        </Typography>
        <Typography>
          <strong>Arrival:</strong>{" "}
          {new Date(flight.arrivalTime).toLocaleString()}
        </Typography>
        <Typography>
          <strong>Price:</strong> Rs. {flight.price}
        </Typography>

        {successMsg && (
          <Alert severity="success" sx={{ mt: 3 }}>
            {successMsg}
          </Alert>
        )}

        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 3 }}
          onClick={handleBooking}
          disabled={booking}
        >
          {booking ? <CircularProgress size={24} /> : "Confirm Booking"}
        </Button>
      </Paper>
    </Container>
  );
}
