import React from "react";
import { Box, Typography, Button, Container } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

export default function Confirmation() {
  const navigate = useNavigate();

  return (
    <Container sx={{ py: 8 }}>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <Box
          sx={{
            backgroundColor: "#f0f9ff",
            p: 6,
            borderRadius: 3,
            textAlign: "center",
            boxShadow: 4,
          }}
        >
          <Typography variant="h4" gutterBottom>
            Booking Confirmed!
          </Typography>
          <Typography variant="body1" mb={4}>
            Thank you for booking your flight with us. You will receive a confirmation email shortly.
          </Typography>
          <Button variant="contained" color="primary" onClick={() => navigate("/")}>Go to Home</Button>
        </Box>
      </motion.div>
    </Container>
  );
}