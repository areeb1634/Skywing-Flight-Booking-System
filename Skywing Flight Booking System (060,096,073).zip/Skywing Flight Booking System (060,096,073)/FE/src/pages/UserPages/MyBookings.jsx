// pages/MyBookings.jsx
import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Paper,
  CircularProgress,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button
} from '@mui/material';
import axios from 'axios';
import Navbar from '../../Component/Navbar';

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const userEmail = localStorage.getItem('userEmail');

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/my-bookings/${userEmail}`);
        setBookings(res.data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      } finally {
        setLoading(false);
      }
    };

    if (userEmail) {
      fetchBookings();
    }
  }, [userEmail]);

  return (
    <div>

        <Navbar/>
    
      <Container maxWidth="lg" sx={{ mt: 8, mb: 4 }}>
      <Typography variant="h4" sx={{ mb: 4, textAlign: 'center', fontWeight: 'bold' }}>
        My Bookings
      </Typography>

      {loading ? (
        <Box display="flex" justifyContent="center" mt={4}>
          <CircularProgress />
        </Box>
      ) : bookings.length === 0 ? (
        <Typography variant="h6" color="text.secondary" textAlign="center">
          No bookings found.
        </Typography>
      ) : (
        <Grid container spacing={3}>
          {bookings.map((booking) => (
            <Grid item xs={12} sm={6} md={4} key={booking.id}>
              <Card elevation={4} sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="h6" fontWeight="bold">
                    {booking.fromCity} → {booking.toCity}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Flight #: {booking.flightNumber}
                  </Typography>
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    Departure: {new Date(booking.departureTime).toLocaleString()}
                  </Typography>
                  <Typography variant="body2">
                    Arrival: {new Date(booking.arrivalTime).toLocaleString()}
                  </Typography>
                  <Typography variant="body1" fontWeight="bold" sx={{ mt: 1 }}>
                    Price: Rs. {booking.price}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button size="small" color="primary">
                    View Details
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
    </div>
  );
};

export default MyBookings;
