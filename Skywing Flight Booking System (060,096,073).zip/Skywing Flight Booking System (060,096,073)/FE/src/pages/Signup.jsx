import React, { useState } from "react";
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  Link,
  useTheme,
  useMediaQuery
} from "@mui/material";
import { motion } from "framer-motion";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/firebaseConfig";
import { useNavigate, Link as RouterLink } from "react-router-dom";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      navigate("/");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Box
      sx={{
        width: "100%",
        minHeight: "98vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "linear-gradient(to right, #43e97b, #38f9d7)",
        px: 2, // Horizontal padding for all screens
        boxSizing: "border-box" // Ensure padding is included in width calculation
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{
          width: "100%",
          maxWidth: 450, // Fixed maximum width for all screens
          margin: "0 auto" // Center the form
        }}
      >
        <Paper
          elevation={6}
          sx={{
            p: { xs: 3, sm: 4 }, // Responsive padding
            borderRadius: { xs: 2, sm: 4 }, // Responsive border radius
            width: "100%",
            boxSizing: "border-box" // Ensure padding is included in width calculation
          }}
        >
          <Typography
            variant="h4"
            textAlign="center"
            gutterBottom
            sx={{
              fontWeight: 600,
              fontSize: { xs: "1.5rem", sm: "2rem" } // Responsive font size
            }}
          >
            Sign Up
          </Typography>

          <Box component="form" onSubmit={handleSignup}>
            <TextField
              label="Email"
              type="email"
              fullWidth
              required
              margin="normal"
              size="medium"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              sx={{ mb: 2 }}
            />

            <TextField
              label="Password"
              type="password"
              fullWidth
              required
              margin="normal"
              size="medium"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              sx={{ mb: 2 }}
            />

            {error && (
              <Typography
                color="error"
                sx={{
                  mt: 1,
                  fontSize: "0.875rem"
                }}
              >
                {error}
              </Typography>
            )}

            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              sx={{
                mt: 3,
                py: 1.5,
                fontWeight: "bold"
              }}
            >
              Create Account
            </Button>

            <Typography
              sx={{
                mt: 2,
                textAlign: "center",
                fontSize: "1rem"
              }}
            >
              Already have an account?{" "}
              <Link
                component={RouterLink}
                to="/login"
                sx={{
                  fontSize: "inherit"
                }}
              >
                Login here
              </Link>
            </Typography>
          </Box>
        </Paper>
      </motion.div>
    </Box>
  );
}