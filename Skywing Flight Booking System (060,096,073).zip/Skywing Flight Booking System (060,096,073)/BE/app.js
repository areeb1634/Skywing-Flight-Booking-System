// backend/server.js
import express from "express";
import cors from "cors";
import mysql from "mysql2/promise";

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Create MySQL connection
const db = await mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "mustafa@1290",
  database: "flight_booking",
});

console.log("✅ Connected to MySQL");

// ----------------------- ADMIN ROUTES ----------------------- //

// Add a flight
app.post("/admin/add-flight", async (req, res) => {
  const { flightNumber, fromCity, toCity, departureTime, arrivalTime, price } = req.body;
  try {
    await db.execute(
      "INSERT INTO flights (flightNumber, fromCity, toCity, departureTime, arrivalTime, price) VALUES (?, ?, ?, ?, ?, ?)",
      [flightNumber, fromCity, toCity, departureTime, arrivalTime, price]
    );
    res.status(200).send("Flight added successfully");
  } catch (err) {
    res.status(500).send(err);
  }
});

// Delete a flight
app.delete("/flights/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const [result] = await db.execute("DELETE FROM flights WHERE id = ?", [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Flight not found" });
    }

    res.json({ message: "Flight deleted successfully" });
  } catch (error) {
    console.error("Error deleting flight:", error.message);
    res.status(500).json({ message: "Server error" });
  }
});

// Edit flight
app.put("/admin/edit-flight/:id", async (req, res) => {
  const { id } = req.params;
  const { flightNumber, fromCity, toCity, departureTime, arrivalTime, price } = req.body;
  try {
    await db.execute(
      `UPDATE flights SET flightNumber=?, fromCity=?, toCity=?, departureTime=?, arrivalTime=?, price=? WHERE id=?`,
      [flightNumber, fromCity, toCity, departureTime, arrivalTime, price, id]
    );
    res.status(200).send("Flight updated successfully");
  } catch (err) {
    res.status(500).send(err);
  }
});

// ----------------------- USER ROUTES ----------------------- //

// Get all flights
app.get("/flights", async (req, res) => {
  try {
    const [rows] = await db.execute("SELECT * FROM flights");
    res.status(200).json(rows);
  } catch (err) {
    res.status(500).send(err);
  }
});

// Book a flight
app.post("/book", async (req, res) => {
  const { userEmail, flightId } = req.body;
  try {
    await db.execute("INSERT INTO bookings (userEmail, flightId) VALUES (?, ?)", [userEmail, flightId]);
    res.status(200).send("Flight booked successfully");
  } catch (err) {
    res.status(500).send(err);
  }
});

// Get all bookings for a user
app.get("/my-bookings/:email", async (req, res) => {
  const { email } = req.params;
  try {
    const [rows] = await db.execute(
      `SELECT b.id, f.flightNumber, f.fromCity, f.toCity, f.departureTime, f.arrivalTime, f.price
       FROM bookings b
       JOIN flights f ON b.flightId = f.id
       WHERE b.userEmail = ?`,
      [email]
    );
    res.status(200).json(rows);
  } catch (err) {
    res.status(500).send(err);
  }
});

// ----------------------- START SERVER ----------------------- //

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
